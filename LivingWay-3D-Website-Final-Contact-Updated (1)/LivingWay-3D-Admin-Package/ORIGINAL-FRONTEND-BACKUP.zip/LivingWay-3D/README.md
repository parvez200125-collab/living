# LivingWay 3D

## Request form

The website uses FormSubmit as the form delivery service, so there is **no custom backend/server code** to deploy.

Customer requests are sent to:

**livingwayd2@gmail.com**

### One-time activation

On the **first** real submission, FormSubmit will send an activation/confirmation email to `livingwayd2@gmail.com`. Open that email and click the confirmation link once. After activation, future customer submissions will be delivered to that inbox.

### Important

- No Gmail password is stored in this website.
- The receiving address is `livingwayd2@gmail.com`.
- Keep the FormSubmit endpoint in `index.html`.
- The `_next` URL currently points to `https://livingway3d.com/thank-you.html`. If your live website uses a different domain, change only the `_next` value in `index.html` to your real `thank-you.html` URL.
